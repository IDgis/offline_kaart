function onBodyLoad() {
	document.addEventListener("deviceready", go, false);
}

var localFileName;	// the filename of the local mbtiles file
var url;

localFileName = 'CA-app/tiles/brt_achtergrondkaart.mbtiles';

function go() {
	
	var fileSystemToGet;
	var devicePlatform = device.platform;
	
	if (devicePlatform === "Android") {
		fileSystemToGet = cordova.file.externalRootDirectory;
	} else {
		fileSystemToGet = LocalFileSystem.PERSISTENT;
	}
	
	console.log('requesting file system ' + fileSystemToGet);
	
	window.resolveLocalFileSystemURL(fileSystemToGet, function (rootDir) {
		console.log('file system root retrieved: ' + rootDir.toURL());

		// check to see if files already exists
		var file = rootDir.getFile(localFileName, {create: false}, function (file) {
			// file exists
			console.log('file ' + localFileName + ' exists');
			
			url = file.toInternalURL();

			buildMap();
		}, function () {
			// file does not exist
			console.log('file ' + localFileName + ' does not exist');
		});
	}, function () {
		console.log('file system not retrieved');
	});
}

function buildMap() {
	window.sqlitePlugin.echoTest(function() {
		console.log('ECHO test OK');
	});
  
	var db = window.sqlitePlugin.openDatabase({name: url, location: 'default'});

	var map = L.map('map').setView([0, 0], 4);

	var lyr = new L.TileLayer.MBTiles('', {maxZoom: 14, scheme: 'tms'}, db);

	map.addLayer(lyr);
}
