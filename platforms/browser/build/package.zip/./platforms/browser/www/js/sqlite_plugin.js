var SQLitePlugin = function (dbPath) {
	
};
